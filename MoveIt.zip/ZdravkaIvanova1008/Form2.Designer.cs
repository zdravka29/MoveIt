﻿namespace ZdravkaIvanova1008
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Form2MenuStrip = new System.Windows.Forms.MenuStrip();
            this.ObjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CircleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SquareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TriangleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ObjColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FrameColorМуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BackColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SpeedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Form2MenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // Form2MenuStrip
            // 
            this.Form2MenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Form2MenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ObjectToolStripMenuItem,
            this.InfoToolStripMenuItem});
            this.Form2MenuStrip.Location = new System.Drawing.Point(0, 0);
            this.Form2MenuStrip.Name = "Form2MenuStrip";
            this.Form2MenuStrip.Size = new System.Drawing.Size(800, 28);
            this.Form2MenuStrip.TabIndex = 0;
            this.Form2MenuStrip.Text = "menuStrip1";
            // 
            // ObjectToolStripMenuItem
            // 
            this.ObjectToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TypeToolStripMenuItem,
            this.ColorToolStripMenuItem,
            this.SpeedToolStripMenuItem});
            this.ObjectToolStripMenuItem.Name = "ObjectToolStripMenuItem";
            this.ObjectToolStripMenuItem.Size = new System.Drawing.Size(90, 24);
            this.ObjectToolStripMenuItem.Text = "За обекта";
            // 
            // TypeToolStripMenuItem
            // 
            this.TypeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CircleToolStripMenuItem,
            this.SquareToolStripMenuItem,
            this.TriangleToolStripMenuItem});
            this.TypeToolStripMenuItem.Name = "TypeToolStripMenuItem";
            this.TypeToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.TypeToolStripMenuItem.Text = "Вид";
            // 
            // CircleToolStripMenuItem
            // 
            this.CircleToolStripMenuItem.Name = "CircleToolStripMenuItem";
            this.CircleToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.CircleToolStripMenuItem.Text = "Кръг";
            this.CircleToolStripMenuItem.Click += new System.EventHandler(this.CircleToolStripMenuItem_Click);
            // 
            // SquareToolStripMenuItem
            // 
            this.SquareToolStripMenuItem.Name = "SquareToolStripMenuItem";
            this.SquareToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.SquareToolStripMenuItem.Text = "Квадрат";
            // 
            // TriangleToolStripMenuItem
            // 
            this.TriangleToolStripMenuItem.Name = "TriangleToolStripMenuItem";
            this.TriangleToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.TriangleToolStripMenuItem.Text = "Триъгълник";
            // 
            // ColorToolStripMenuItem
            // 
            this.ColorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ObjColorToolStripMenuItem,
            this.FrameColorМуToolStripMenuItem,
            this.BackColorToolStripMenuItem});
            this.ColorToolStripMenuItem.Name = "ColorToolStripMenuItem";
            this.ColorToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.ColorToolStripMenuItem.Text = "Цвят";
            // 
            // ObjColorToolStripMenuItem
            // 
            this.ObjColorToolStripMenuItem.Name = "ObjColorToolStripMenuItem";
            this.ObjColorToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.ObjColorToolStripMenuItem.Text = "На обекта";
            // 
            // FrameColorМуToolStripMenuItem
            // 
            this.FrameColorМуToolStripMenuItem.Name = "FrameColorМуToolStripMenuItem";
            this.FrameColorМуToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.FrameColorМуToolStripMenuItem.Text = "На рамката му";
            // 
            // BackColorToolStripMenuItem
            // 
            this.BackColorToolStripMenuItem.Name = "BackColorToolStripMenuItem";
            this.BackColorToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.BackColorToolStripMenuItem.Text = "На фона";
            // 
            // SpeedToolStripMenuItem
            // 
            this.SpeedToolStripMenuItem.Name = "SpeedToolStripMenuItem";
            this.SpeedToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.SpeedToolStripMenuItem.Text = "Скорост на движение";
            // 
            // InfoToolStripMenuItem
            // 
            this.InfoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AboutToolStripMenuItem});
            this.InfoToolStripMenuItem.Name = "InfoToolStripMenuItem";
            this.InfoToolStripMenuItem.Size = new System.Drawing.Size(116, 24);
            this.InfoToolStripMenuItem.Text = "Информация";
            // 
            // AboutToolStripMenuItem
            // 
            this.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem";
            this.AboutToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.AboutToolStripMenuItem.Text = "Какво прави тази програма";
            this.AboutToolStripMenuItem.Click += new System.EventHandler(this.AboutToolStripMenuItem_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Form2MenuStrip);
            this.MainMenuStrip = this.Form2MenuStrip;
            this.Name = "Form2";
            this.Text = "Задача 9.";
            this.Form2MenuStrip.ResumeLayout(false);
            this.Form2MenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem ObjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CircleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SquareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TriangleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ObjColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem FrameColorМуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem BackColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SpeedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem InfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AboutToolStripMenuItem;
        public System.Windows.Forms.MenuStrip Form2MenuStrip;
    }
}